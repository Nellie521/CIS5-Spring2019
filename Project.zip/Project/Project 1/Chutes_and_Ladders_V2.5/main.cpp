/* 
 * File:   main.cpp
 * Author: Nellie Garcia
 * Created on April 8th, 2019, 1:16 PM
 * Purpose:  Chutes and Ladders Version 2.5
 *           1-4 players
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cstdlib>   //C Standard Library - Random Number
#include <ctime>     //Time Library
#include <iomanip>   //Format Library
#include <cmath>     //Math Library
#include <fstream>   //File Library
#include <string>    //String Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    unsigned int    die,    //Die input
                    nPlayer,//Number of players
                    place1, //Place for player 1
                    place2, //Place for player 2
                    place3, //Place for player 3
                    place4; //Place for player 4
    bool            win;    //Win/Lose
    bool            again;  //Play again?
    bool            end1,   //End first player's turn
                    end2,   //End second player's turn
                    end3,   //End third player's turn
                    end4;   //End fourth player's turn
    
    //Initialize or input i.e. set variable values
    cout<<"Chutes and Ladders Game"<<endl;
    cout<<"The goal is to reach number 100"<<endl;
    cout<<"You can have up to four players"<<endl;
    cout<<"Enter the number of players: ";
    cin>>nPlayer;
    place1=place2=place3=place4=0;
    win=false;
    end1=end2=end3=end4=false;
    again=false;
    
    //Map inputs -> outputs
    if (nPlayer==1) {
        //One player
        do {
            die=rand()%6+1;     //Dice roll
            place1+=die;        //Place before chutes or ladders

            //Place cannot go over 100
            while (place1>100) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"You cannot land over 100. Go back!"<<endl;
                place1-=die;    //Backtrack place1
            }

            //Testing chutes and ladders
            if (place1==1) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved up a ladder!"<<endl;
                place1=38;
            }
            else if (place1==4) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved up a ladder!"<<endl;
                place1=14;
            }
            else if (place1==9) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved up a ladder!"<<endl;
                place1=31;
            }
            else if (place1==16) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved down a chute!"<<endl;
                place1=6;
            }
            else if (place1==21) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved up a ladder!"<<endl;
                place1=42;
            }
            else if (place1==28) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved up a ladder!"<<endl;
                place1=84;
            }
            else if (place1==36) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved up a ladder!"<<endl;
                place1=44;
            }
            else if (place1==47) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved down a chute!"<<endl;
                place1=26;
            }
            else if (place1==49) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved down a chute!"<<endl;
                place1=11;
            }
            else if (place1==51) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved up a ladder!"<<endl;
                place1=67;
            }
            else if (place1==56) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved down a chute!"<<endl;
                place1=53;
            }
            else if (place1==62) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved down a chute!"<<endl;
                place1=19;
            }
            else if (place1==64) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved down a chute!"<<endl;
                place1=60;
            }
            else if (place1==71) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved up a ladder!"<<endl;
                place1=91;
            }
            else if (place1==80) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved up a ladder!"<<endl;
                place1=100;
            }
            else if (place1==87) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved down a chute!"<<endl;
                place1=24;
            }
            else if (place1==93) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved down a chute!"<<endl;
                place1=73;
            }
            else if (place1==95) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved down a chute!"<<endl;
                place1=75;
            }
            else if (place1==98) {
                cout<<"Player 1 number: "<<place1<<endl;
                cout<<"Player 1 moved down a chute!"<<endl;
                place1=78;
            }

            //Output place1
            cout<<"Player 1 number: "<<place1<<endl;

            //Win Determination
            if (place1==100) {
                win=true;
            }
        }while (win==false);
    }
    
        //Two players
        if (nPlayer==2) {
            //Loop turns in order
            do {
                //First player's turn
                do {
                    die=rand()%6+1;     //Dice roll
                    place1+=die;        //Place before chutes or ladders

                    //Place cannot go over 100
                    while (place1>100) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"You cannot land over 100. Go back!"<<endl;
                        place1-=die;   //Backtrack place1
                    }

                    //Testing chutes and ladders
                    if (place1==1) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved up a ladder!"<<endl;
                        place1=38;
                    }
                    else if (place1==4) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved up a ladder!"<<endl;
                        place1=14;
                    }
                    else if (place1==9) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved up a ladder!"<<endl;
                        place1=31;
                    }
                    else if (place1==16) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved down a chute!"<<endl;
                        place1=6;
                    }
                    else if (place1==21) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved up a ladder!"<<endl;
                        place1=42;
                    }
                    else if (place1==28) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved up a ladder!"<<endl;
                        place1=84;
                    }
                    else if (place1==36) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved up a ladder!"<<endl;
                        place1=44;
                    }
                    else if (place1==47) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved down a chute!"<<endl;
                        place1=26;
                    }
                    else if (place1==49) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved down a chute!"<<endl;
                        place1=11;
                    }
                    else if (place1==51) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved up a ladder!"<<endl;
                        place1=67;
                    }
                    else if (place1==56) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved down a chute!"<<endl;
                        place1=53;
                    }
                    else if (place1==62) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved down a chute!"<<endl;
                        place1=19;
                    }
                    else if (place1==64) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved down a chute!"<<endl;
                        place1=60;
                    }
                    else if (place1==71) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved up a ladder!"<<endl;
                        place1=91;
                    }
                    else if (place1==80) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved up a ladder!"<<endl;
                        place1=100;
                    }
                    else if (place1==87) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved down a chute!"<<endl;
                        place1=24;
                    }
                    else if (place1==93) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved down a chute!"<<endl;
                        place1=73;
                    }
                    else if (place1==95) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved down a chute!"<<endl;
                        place1=75;
                    }
                    else if (place1==98) {
                        cout<<"Player 1 number: "<<place1<<endl;
                        cout<<"Player 1 moved down a chute!"<<endl;
                        place1=78;
                    }

                    //Output place1
                    cout<<"Player 1 number: "<<place1<<endl;

                    //Win Determination
                    if (place1==100) {
                        win=true;
                    }

                    //End first player's turn
                    end1=true;

                }while (end1==false);
                //Second player's turn
                do {
                    die=rand()%6+1;     //Dice roll
                    place2+=die;        //Place before chutes or ladders

                    //Place cannot go over 100
                    while (place2>100) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"You cannot land over 100. Go back!"<<endl;
                        place2-=die;    //Backtrack place2
                    }

                    //Testing chutes and ladders
                    if (place2==1) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved up a ladder!"<<endl;
                        place2=38;
                    }
                    else if (place2==4) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved up a ladder!"<<endl;
                        place2=14;
                    }
                    else if (place2==9) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved up a ladder!"<<endl;
                        place2=31;
                    }
                    else if (place2==16) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved down a chute!"<<endl;
                        place2=6;
                    }
                    else if (place2==21) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved up a ladder!"<<endl;
                        place2=42;
                    }
                    else if (place2==28) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved up a ladder!"<<endl;
                        place2=84;
                    }
                    else if (place2==36) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved up a ladder!"<<endl;
                        place2=44;
                    }
                    else if (place2==47) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved down a chute!"<<endl;
                        place2=26;
                    }
                    else if (place2==49) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved down a chute!"<<endl;
                        place2=11;
                    }
                    else if (place2==51) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved up a ladder!"<<endl;
                        place2=67;
                    }
                    else if (place2==56) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved down a chute!"<<endl;
                        place2=53;
                    }
                    else if (place2==62) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved down a chute!"<<endl;
                        place2=19;
                    }
                    else if (place2==64) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved down a chute!"<<endl;
                        place2=60;
                    }
                    else if (place2==71) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved up a ladder!"<<endl;
                        place2=91;
                    }
                    else if (place2==80) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved up a ladder!"<<endl;
                        place2=100;
                    }
                    else if (place2==87) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved down a chute!"<<endl;
                        place2=24;
                    }
                    else if (place2==93) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved down a chute!"<<endl;
                        place2=73;
                    }
                    else if (place2==95) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved down a chute!"<<endl;
                        place2=75;
                    }
                    else if (place2==98) {
                        cout<<"Player 2 number: "<<place2<<endl;
                        cout<<"Player 2 moved down a chute!"<<endl;
                        place2=78;
                    }

                    //Output place2
                    cout<<"Player 2 number: "<<place2<<endl;

                    //Win Determination
                    if (place2==100) {
                        win=true;
                    }

                    //End second player's turn
                    end1=false;
                    end2=true;
                }while(end2==false);
            }while (win==false);
        }
    
    //Three players
    if (nPlayer==3) {
        //Loop turns in order
        do {
            //First player's turn
            do {
                die=rand()%6+1;     //Dice roll
                place1+=die;        //Place before chutes or ladders

                //Place cannot go over 100
                while (place1>100) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"You cannot land over 100. Go back!"<<endl;
                    place1-=die;    //Backtrack place1
                }

                //Testing chutes and ladders
                if (place1==1) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=38;
                }
                else if (place1==4) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=14;
                }
                else if (place1==9) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=31;
                }
                else if (place1==16) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=6;
                }
                else if (place1==21) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=42;
                }
                else if (place1==28) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=84;
                }
                else if (place1==36) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=44;
                }
                else if (place1==47) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=26;
                }
                else if (place1==49) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=11;
                }
                else if (place1==51) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=67;
                }
                else if (place1==56) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=53;
                }
                else if (place1==62) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=19;
                }
                else if (place1==64) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=60;
                }
                else if (place1==71) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=91;
                }
                else if (place1==80) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=100;
                }
                else if (place1==87) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=24;
                }
                else if (place1==93) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=73;
                }
                else if (place1==95) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=75;
                }
                else if (place1==98) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=78;
                }

                //Output place1
                cout<<"Player 1 number: "<<place1<<endl;

                //Win Determination
                if (place1==100) {
                    win=true;
                }

                //End first player's turn
                end1=true;
            }while (end1==false);
            //Second player's turn
            do {
                die=rand()%6+1;     //Dice roll
                place2+=die;        //Place before chutes or ladders

                //Place cannot go over 100
                while (place2>100) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"You cannot land over 100. Go back!"<<endl;
                    place2-=die;    //Backtrack place2
                }

                //Testing chutes and ladders
                if (place2==1) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=38;
                }
                else if (place2==4) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=14;
                }
                else if (place2==9) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=31;
                }
                else if (place2==16) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=6;
                }
                else if (place2==21) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=42;
                }
                else if (place2==28) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=84;
                }
                else if (place2==36) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=44;
                }
                else if (place2==47) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=26;
                }
                else if (place2==49) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=11;
                }
                else if (place2==51) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=67;
                }
                else if (place2==56) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=53;
                }
                else if (place2==62) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=19;
                }
                else if (place2==64) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=60;
                }
                else if (place2==71) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=91;
                }
                else if (place2==80) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=100;
                }
                else if (place2==87) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=24;
                }
                else if (place2==93) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=73;
                }
                else if (place2==95) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=75;
                }
                else if (place2==98) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=78;
                }

                //Output place2
                cout<<"Player 2 number: "<<place2<<endl;

                //Win Determination
                if (place2==100) {
                    win=true;
                }

                //End second player's turn
                end2=true;
            }while(end2==false);
            //Third player's turn
            do {
                die=rand()%6+1;     //Dice roll
                place3+=die;        //Place before chutes or ladders

                //Place cannot go over 100
                while (place3>100) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"You cannot land over 100. Go back!"<<endl;
                    place3-=die;    //Backtrack place3
                }

                //Testing chutes and ladders
                if (place3==1) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=38;
                }
                else if (place3==4) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=14;
                }
                else if (place3==9) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=31;
                }
                else if (place3==16) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=6;
                }
                else if (place3==21) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=42;
                }
                else if (place3==28) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=84;
                }
                else if (place3==36) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=44;
                }
                else if (place3==47) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=26;
                }
                else if (place3==49) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=11;
                }
                else if (place3==51) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=67;
                }
                else if (place3==56) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=53;
                }
                else if (place3==62) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=19;
                }
                else if (place3==64) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=60;
                }
                else if (place3==71) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=91;
                }
                else if (place3==80) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=100;
                }
                else if (place3==87) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=24;
                }
                else if (place3==93) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=73;
                }
                else if (place3==95) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=75;
                }
                else if (place3==98) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=78;
                }

                //Output place3
                cout<<"Player 3 number: "<<place3<<endl;

                //Win Determination
                if (place3==100) {
                    win=true;
                }

                //End third player's turn - reset other turns
                end1=false;
                end2=false;
                end3=true;
            }while(end3==false);
        }while (win==false);
    }
    //Four players
    if (nPlayer==4) {
        //Loop turns in order
        do {
            //First player's turn
            do {
                die=rand()%6+1;     //Dice roll
                place1+=die;        //Place before chutes or ladders

                //Place cannot go over 100
                while (place1>100) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"You cannot land over 100. Go back!"<<endl;
                    place1-=die;    //Backtrack place1
                }

                //Testing chutes and ladders
                if (place1==1) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=38;
                }
                else if (place1==4) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=14;
                }
                else if (place1==9) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=31;
                }
                else if (place1==16) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=6;
                }
                else if (place1==21) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=42;
                }
                else if (place1==28) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=84;
                }
                else if (place1==36) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=44;
                }
                else if (place1==47) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=26;
                }
                else if (place1==49) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=11;
                }
                else if (place1==51) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=67;
                }
                else if (place1==56) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=53;
                }
                else if (place1==62) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=19;
                }
                else if (place1==64) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=60;
                }
                else if (place1==71) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=91;
                }
                else if (place1==80) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved up a ladder!"<<endl;
                    place1=100;
                }
                else if (place1==87) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=24;
                }
                else if (place1==93) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=73;
                }
                else if (place1==95) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=75;
                }
                else if (place1==98) {
                    cout<<"Player 1 number: "<<place1<<endl;
                    cout<<"Player 1 moved down a chute!"<<endl;
                    place1=78;
                }

                //Output place1
                cout<<"Player 1 number: "<<place1<<endl;

                //Win Determination
                if (place1==100) {
                    win=true;
                }

                //End first player's turn
                end1=true;
            }while (end1==false);
            //Second player's turn
            do {
                die=rand()%6+1;     //Dice roll
                place2+=die;        //Place before chutes or ladders

                //Place cannot go over 100
                while (place2>100) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"You cannot land over 100. Go back!"<<endl;
                    place2-=die;    //Backtrack place2
                }

                //Testing chutes and ladders
                if (place2==1) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=38;
                }
                else if (place2==4) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=14;
                }
                else if (place2==9) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=31;
                }
                else if (place2==16) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=6;
                }
                else if (place2==21) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=42;
                }
                else if (place2==28) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=84;
                }
                else if (place2==36) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=44;
                }
                else if (place2==47) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=26;
                }
                else if (place2==49) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=11;
                }
                else if (place2==51) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=67;
                }
                else if (place2==56) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=53;
                }
                else if (place2==62) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=19;
                }
                else if (place2==64) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=60;
                }
                else if (place2==71) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=91;
                }
                else if (place2==80) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved up a ladder!"<<endl;
                    place2=100;
                }
                else if (place2==87) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=24;
                }
                else if (place2==93) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=73;
                }
                else if (place2==95) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=75;
                }
                else if (place2==98) {
                    cout<<"Player 2 number: "<<place2<<endl;
                    cout<<"Player 2 moved down a chute!"<<endl;
                    place2=78;
                }

                //Output place2
                cout<<"Player 2 number: "<<place2<<endl;

                //Win Determination
                if (place2==100) {
                    win=true;
                }

                //End second player's turn
                end2=true;
            }while(end2==false);
            //Third player's turn
            do {
                die=rand()%6+1;     //Dice roll
                place3+=die;        //Place before chutes or ladders

                //Place cannot go over 100
                while (place3>100) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"You cannot land over 100. Go back!"<<endl;
                    place3-=die;    //Backtrack place3
                }

                //Testing chutes and ladders
                if (place3==1) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=38;
                }
                else if (place3==4) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=14;
                }
                else if (place3==9) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=31;
                }
                else if (place3==16) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=6;
                }
                else if (place3==21) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=42;
                }
                else if (place3==28) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=84;
                }
                else if (place3==36) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=44;
                }
                else if (place3==47) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=26;
                }
                else if (place3==49) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=11;
                }
                else if (place3==51) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=67;
                }
                else if (place3==56) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=53;
                }
                else if (place3==62) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=19;
                }
                else if (place3==64) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=60;
                }
                else if (place3==71) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=91;
                }
                else if (place3==80) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved up a ladder!"<<endl;
                    place3=100;
                }
                else if (place3==87) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=24;
                }
                else if (place3==93) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=73;
                }
                else if (place3==95) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=75;
                }
                else if (place3==98) {
                    cout<<"Player 3 number: "<<place3<<endl;
                    cout<<"Player 3 moved down a chute!"<<endl;
                    place3=78;
                }

                //Output place3
                cout<<"Player 3 number: "<<place3<<endl;

                //Win Determination
                if (place3==100) {
                    win=true;
                }

                //End third player's turn
                end3=true;
            }while(end3==false);
            //Fourth player's turn
            do {
                die=rand()%6+1;     //Dice roll
                place4+=die;        //Place before chutes or ladders

                //Place cannot go over 100
                while (place4>100) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"You cannot land over 100. Go back!"<<endl;
                    place4-=die;    //Backtrack place4
                }

                //Testing chutes and ladders
                if (place4==1) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved up a ladder!"<<endl;
                    place4=38;
                }
                else if (place4==4) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved up a ladder!"<<endl;
                    place4=14;
                }
                else if (place4==9) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved up a ladder!"<<endl;
                    place4=31;
                }
                else if (place4==16) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved down a chute!"<<endl;
                    place4=6;
                }
                else if (place4==21) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved up a ladder!"<<endl;
                    place4=42;
                }
                else if (place4==28) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved up a ladder!"<<endl;
                    place4=84;
                }
                else if (place4==36) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved up a ladder!"<<endl;
                    place4=44;
                }
                else if (place4==47) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved down a chute!"<<endl;
                    place4=26;
                }
                else if (place4==49) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved down a chute!"<<endl;
                    place4=11;
                }
                else if (place4==51) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved up a ladder!"<<endl;
                    place4=67;
                }
                else if (place4==56) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved down a chute!"<<endl;
                    place4=53;
                }
                else if (place4==62) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved down a chute!"<<endl;
                    place4=19;
                }
                else if (place4==64) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved down a chute!"<<endl;
                    place4=60;
                }
                else if (place4==71) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved up a ladder!"<<endl;
                    place4=91;
                }
                else if (place4==80) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved up a ladder!"<<endl;
                    place4=100;
                }
                else if (place4==87) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved down a chute!"<<endl;
                    place4=24;
                }
                else if (place4==93) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved down a chute!"<<endl;
                    place4=73;
                }
                else if (place4==95) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved down a chute!"<<endl;
                    place4=75;
                }
                else if (place4==98) {
                    cout<<"Player 4 number: "<<place4<<endl;
                    cout<<"Player 4 moved down a chute!"<<endl;
                    place4=78;
                }

                //Output place4
                cout<<"Player 4 number: "<<place4<<endl;

                //Win Determination
                if (place4==100) {
                    win=true;
                }

                //End fourth player's turn - reset other turns
                end1=false;
                end2=false;
                end3=false;
                end4=true;
            }while(end4==false);
        }while (win==false);
    }
    
    //Display the outputs
    if (win==true) {
        cout<<"You win!"<<endl;
    }

    //Exit stage right or left!
    return 0;
}