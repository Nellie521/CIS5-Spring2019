/* 
 * File:   main.cpp
 * Author: Nellie Garcia
 * Created on April 12th, 2019, 10:41 AM
 * Purpose:  Chutes and Ladders Version 4
 *           Multiple number of games and switch statement
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cstdlib>   //C Standard Library - Random Number
#include <ctime>     //Time Library
#include <iomanip>   //Format Library
#include <cmath>     //Math Library
#include <fstream>   //File Library
#include <string>    //String Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    unsigned int    die,    //Die input
                    nPlayer,//Number of players
                    place1, //Place for player 1
                    place2, //Place for player 2
                    nGames; //Number of games
    bool            win1,   //Win/Lose for player 1
                    win2;   //Win/Lose for player 2
    bool            end1,   //End first player's turn
                    end2;   //End second player's turn
    
    //Initialize or input i.e. set variable values
    cout<<"Chutes and Ladders Game"<<endl;
    cout<<"The goal is to reach number 100"<<endl;
    cout<<"You can have up to two players"<<endl;
    cout<<"Enter the number of players: ";
    cin>>nPlayer;
    cout<<"Enter the number of games you want to play: ";
    cin>>nGames;
    cout<<endl;
    place1=place2=0;
    win1=win2=false;
    end1=end2=false;
    
    //Map inputs -> outputs
    switch (nPlayer) {
        //One player
        case 1: {
            if (nPlayer==1) {
                for(int i=1;i<=nGames;i++) {

                    //Reset place and wins
                    place1=0;
                    win1=false;

                    //Begin game
                    do {
                        if (place1<100) {
                            die=rand()%6+1;     //Dice roll
                            place1+=die;        //Place before chutes or ladders
                        }

                        //Place cannot go over 100
                        while (place1>100) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"You cannot land over 100. Go back!"<<endl;
                            place1-=die;    //Backtrack place1
                        }

                        //Testing chutes and ladders
                        if (place1==1) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved up a ladder!"<<endl;
                            place1=38;
                        }
                        else if (place1==4) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved up a ladder!"<<endl;
                            place1=14;
                        }
                        else if (place1==9) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved up a ladder!"<<endl;
                            place1=31;
                        }
                        else if (place1==16) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved down a chute!"<<endl;
                            place1=6;
                        }
                        else if (place1==21) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved up a ladder!"<<endl;
                            place1=42;
                        }
                        else if (place1==28) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved up a ladder!"<<endl;
                            place1=84;
                        }
                        else if (place1==36) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved up a ladder!"<<endl;
                            place1=44;
                        }
                        else if (place1==47) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved down a chute!"<<endl;
                            place1=26;
                        }
                        else if (place1==49) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved down a chute!"<<endl;
                            place1=11;
                        }
                        else if (place1==51) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved up a ladder!"<<endl;
                            place1=67;
                        }
                        else if (place1==56) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved down a chute!"<<endl;
                            place1=53;
                        }
                        else if (place1==62) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved down a chute!"<<endl;
                            place1=19;
                        }
                        else if (place1==64) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved down a chute!"<<endl;
                            place1=60;
                        }
                        else if (place1==71) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved up a ladder!"<<endl;
                            place1=91;
                        }
                        else if (place1==80) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved up a ladder!"<<endl;
                            place1=100;
                        }
                        else if (place1==87) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved down a chute!"<<endl;
                            place1=24;
                        }
                        else if (place1==93) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved down a chute!"<<endl;
                            place1=73;
                        }
                        else if (place1==95) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved down a chute!"<<endl;
                            place1=75;
                        }
                        else if (place1==98) {
                            cout<<"Player 1 number: "<<place1<<endl;
                            cout<<"Player 1 moved down a chute!"<<endl;
                            place1=78;
                        }

                        //Output place1
                        cout<<"Player 1 number: "<<place1<<endl;

                        //Win Determination
                        if (place1==100) {
                            win1=true;
                        }
                    }while(win1==false&&place1!=100);

                    //Display who wins
                    if (win1==true||win2==true) {
                        if (win1==true) {
                            cout<<"\nPlayer 1 wins!\n"<<endl;
                        }
                        else cout<<"\nPlayer 2 wins!\n"<<endl;
                    }
                }
            }
        }

        //Two players
        case 2: {
            if (nPlayer==2) {
                for (int i=1;i<=nGames;i++) {

                    //Reset place, wins, and ends
                    place1=place2=0;
                    win1=win2=end1=end2=false;

                    //Loop turns in order
                    do {
                        //First player's turn
                        do {
                            die=rand()%6+1;     //Dice roll
                            place1+=die;        //Place before chutes or ladders

                            //Place cannot go over 100
                            while (place1>100) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"You cannot land over 100. Go back!"<<endl;
                                place1-=die;   //Backtrack place1
                            }

                            //Testing chutes and ladders
                            if (place1==1) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved up a ladder!"<<endl;
                                place1=38;
                            }
                            else if (place1==4) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved up a ladder!"<<endl;
                                place1=14;
                            }
                            else if (place1==9) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved up a ladder!"<<endl;
                                place1=31;
                            }
                            else if (place1==16) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved down a chute!"<<endl;
                                place1=6;
                            }
                            else if (place1==21) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved up a ladder!"<<endl;
                                place1=42;
                            }
                            else if (place1==28) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved up a ladder!"<<endl;
                                place1=84;
                            }
                            else if (place1==36) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved up a ladder!"<<endl;
                                place1=44;
                            }
                            else if (place1==47) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved down a chute!"<<endl;
                                place1=26;
                            }
                            else if (place1==49) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved down a chute!"<<endl;
                                place1=11;
                            }
                            else if (place1==51) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved up a ladder!"<<endl;
                                place1=67;
                            }
                            else if (place1==56) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved down a chute!"<<endl;
                                place1=53;
                            }
                            else if (place1==62) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved down a chute!"<<endl;
                                place1=19;
                            }
                            else if (place1==64) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved down a chute!"<<endl;
                                place1=60;
                            }
                            else if (place1==71) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved up a ladder!"<<endl;
                                place1=91;
                            }
                            else if (place1==80) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved up a ladder!"<<endl;
                                place1=100;
                            }
                            else if (place1==87) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved down a chute!"<<endl;
                                place1=24;
                            }
                            else if (place1==93) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved down a chute!"<<endl;
                                place1=73;
                            }
                            else if (place1==95) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved down a chute!"<<endl;
                                place1=75;
                            }
                            else if (place1==98) {
                                cout<<"Player 1 number: "<<place1<<endl;
                                cout<<"Player 1 moved down a chute!"<<endl;
                                place1=78;
                            }

                            //Output place1
                            cout<<"Player 1 number: "<<place1<<endl;

                            //Win Determination
                            if (place1==100) {
                                win1=true;
                            }

                            //End first player's turn
                            end1=true;
                            end2=false;

                            //End of game?
                            if (win1==true) {
                                end2=true;
                            }

                        }while (end1==false);

                        //Second player's turn
                        while (end2==false) {
                            die=rand()%6+1;     //Dice roll
                            place2+=die;        //Place before chutes or ladders

                            //Place cannot go over 100
                            while (place2>100) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"You cannot land over 100. Go back!"<<endl;
                                place2-=die;    //Backtrack place2
                            }

                            //Testing chutes and ladders
                            if (place2==1) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved up a ladder!"<<endl;
                                place2=38;
                            }
                            else if (place2==4) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved up a ladder!"<<endl;
                                place2=14;
                            }
                            else if (place2==9) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved up a ladder!"<<endl;
                                place2=31;
                            }
                            else if (place2==16) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved down a chute!"<<endl;
                                place2=6;
                            }
                            else if (place2==21) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved up a ladder!"<<endl;
                                place2=42;
                            }
                            else if (place2==28) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved up a ladder!"<<endl;
                                place2=84;
                            }
                            else if (place2==36) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved up a ladder!"<<endl;
                                place2=44;
                            }
                            else if (place2==47) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved down a chute!"<<endl;
                                place2=26;
                            }
                            else if (place2==49) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved down a chute!"<<endl;
                                place2=11;
                            }
                            else if (place2==51) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved up a ladder!"<<endl;
                                place2=67;
                            }
                            else if (place2==56) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved down a chute!"<<endl;
                                place2=53;
                            }
                            else if (place2==62) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved down a chute!"<<endl;
                                place2=19;
                            }
                            else if (place2==64) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved down a chute!"<<endl;
                                place2=60;
                            }
                            else if (place2==71) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved up a ladder!"<<endl;
                                place2=91;
                            }
                            else if (place2==80) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved up a ladder!"<<endl;
                                place2=100;
                            }
                            else if (place2==87) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved down a chute!"<<endl;
                                place2=24;
                            }
                            else if (place2==93) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved down a chute!"<<endl;
                                place2=73;
                            }
                            else if (place2==95) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved down a chute!"<<endl;
                                place2=75;
                            }
                            else if (place2==98) {
                                cout<<"Player 2 number: "<<place2<<endl;
                                cout<<"Player 2 moved down a chute!"<<endl;
                                place2=78;
                            }

                            //Output place2
                            cout<<"Player 2 number: "<<place2<<endl;

                            //Win Determination
                            if (place2==100) {
                                win2=true;
                            }

                            //End second player's turn
                            end1=false;
                            end2=true;
                        }
                    }while (win1==false&&win2==false);

                    //Display who wins
                    if (win1==true||win2==true) {
                        if (win1==true) {
                            cout<<"\nPlayer 1 wins!\n"<<endl;
                        }
                        else cout<<"\nPlayer 2 wins!\n"<<endl;
                    }
                }
            }
        }
    }
    
    //Exit stage right or left!
    return 0;
}